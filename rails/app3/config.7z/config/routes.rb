Rails.application.routes.draw do
  get 'welcome/index'
  
  resource :user_session
  
  #resource :account, :controller => 'users'
  #resources :users
  
  resources :articles
  #articles GET    /articles(.:format)          articles#index
  
  resources :articles do
	resources :comments
  end
  
  root 'welcome#index'
end
