Learn Rails
================

Developed by fullarray
-------------
Please get in touch with me via github if you have any questions. 

Orchestrator
-------------
This application base was generated with the [rails_apps_composer](https://github.com/RailsApps/rails_apps_composer) gem)

Ruby on Rails
-------------

This application requires:

- Ruby 2.4.2
- Rails 5.1.2
