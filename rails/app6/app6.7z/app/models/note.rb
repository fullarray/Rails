class Note < ApplicationRecord
end
